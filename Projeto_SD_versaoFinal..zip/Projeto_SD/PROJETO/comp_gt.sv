module comp_gt (
    input  wire [4:0] A,
    input  wire [4:0] B,
    output wire       gt
);
    wire sA = A[4];
    wire sB = B[4];
    wire [3:0] magA = A[3:0];
    wire [3:0] magB = B[3:0];

    wire mag_gt = (magA > magB);
    wire mag_lt = (magA < magB);

    assign gt = (~sA & sB) | (~sA & ~sB & mag_gt) | (sA & sB & mag_lt);

endmodule