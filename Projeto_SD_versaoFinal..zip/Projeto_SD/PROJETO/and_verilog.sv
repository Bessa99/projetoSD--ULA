module gate_and_5bit (
    input  wire [4:0] A,
    input  wire [4:0] B,
    output wire [5:0] out
);
    assign out = {1'b0, A & B};

endmodule